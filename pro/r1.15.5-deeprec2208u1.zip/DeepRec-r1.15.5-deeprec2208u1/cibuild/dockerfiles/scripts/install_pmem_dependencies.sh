#!/bin/bash

apt update
apt install -y libpmem-dev libmemkind-dev