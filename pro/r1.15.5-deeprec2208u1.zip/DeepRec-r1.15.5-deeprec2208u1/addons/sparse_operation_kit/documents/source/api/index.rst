SparseOperationKit API
======================

.. toctree::
   :maxdepth: 2

   Initialize <init>
   Embeddings <embeddings/index>
   Optimizers <optimizers/opts>
   Utilities <utils/index>
