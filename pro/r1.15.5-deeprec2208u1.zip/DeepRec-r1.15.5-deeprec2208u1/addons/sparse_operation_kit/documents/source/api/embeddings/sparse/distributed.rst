Distributed Sparse Embedding
============================

.. autoclass:: sparse_operation_kit.embeddings.distributed_embedding.DistributedEmbedding
   :members: call
   :show-inheritance: