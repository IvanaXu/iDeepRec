SparseOperationKit Optimizers
=============================
There are several optimized optimizers inside SOK.

Adam optimizer
--------------
.. autoclass:: sparse_operation_kit.tf.keras.optimizers.adam.Adam
    :members:

Local update Adam optimizer
---------------------------
.. autoclass:: sparse_operation_kit.tf.keras.optimizers.lazy_adam.LazyAdamOptimizer
    :members: