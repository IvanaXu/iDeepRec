SparseOperationKit Optimizer Scope
==================================

.. autoclass:: sparse_operation_kit.core.context_scope.OptimizerScope
   :members:
