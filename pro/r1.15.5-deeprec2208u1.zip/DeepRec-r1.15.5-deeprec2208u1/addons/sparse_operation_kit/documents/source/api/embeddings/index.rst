SparseOperationKit Embeddings
=============================

.. toctree::
   :maxdepth: 2

   Sparse Embeddings <sparse/index>
   Dense Embeddings <dense/index>
   Saver <saver>
   TF Distributed Embedding <tf_distributed_embedding>