All2All Dense Embedding
============================

.. autoclass:: sparse_operation_kit.embeddings.all2all_dense_embedding.All2AllDenseEmbedding
   :members: call
   :show-inheritance: