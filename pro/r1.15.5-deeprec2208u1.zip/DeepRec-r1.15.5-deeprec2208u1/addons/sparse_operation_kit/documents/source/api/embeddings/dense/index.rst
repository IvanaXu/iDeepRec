SparseOperationKit Dense Embeddings
===================================
There are several dense embedding implementations, and all of them 
are equivalent to ``tf.nn.embedding_lookup``.

.. toctree::
   :maxdepth: 2

   All2All Dense Embedding <all2all>