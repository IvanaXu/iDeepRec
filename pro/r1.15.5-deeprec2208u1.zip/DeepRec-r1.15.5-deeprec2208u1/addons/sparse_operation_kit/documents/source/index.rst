.. SparseOperationKit documentation master file, created by
   sphinx-quickstart on Thu Jul 22 04:32:10 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to SparseOperationKit's documentation!
==============================================

.. toctree::
   :maxdepth: 2
   
   Introduction <intro_link>
   Features <features/features>
   Get Started <get_started/get_started>
   Examples <examples/index>
   Performance <performance/index>
   API Docs <api/index>
   Release Notes <release_notes/release_notes>
   Environment Variables <env_vars/env_vars>
   Known Issues <known_issues/issues>
