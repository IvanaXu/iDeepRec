Performance
===========

Performance of DLRM with Criteo TeraByte dataset will be added after PerfLab verified it.


.. toctree::
   :maxdepth: 1
   
   DenseDemo <dense_demo>