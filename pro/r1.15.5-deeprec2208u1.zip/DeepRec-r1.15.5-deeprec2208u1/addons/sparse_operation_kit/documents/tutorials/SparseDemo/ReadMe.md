# Demo model using Sparse Embedding Layer #
This file demonstrates how to build a DNN model with sparse embedding layer, where reduction will be conducted intra each slot (feature-filed), with TensorFlow and SparseOperationKit.

## steps ##