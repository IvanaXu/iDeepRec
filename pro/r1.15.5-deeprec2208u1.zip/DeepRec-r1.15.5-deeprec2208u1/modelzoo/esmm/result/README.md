# Result
Checkpoint & timeline file are by default saved in this folder.
