# Dataset
## Prepare dataset
Put data file **train.csv & eval.csv** into ./data/

Use Taobao dataset from [EasyRec](https://github.com/AlibabaPAI/EasyRec/#GetStarted)
