# Dataset
## Prepare dataset
Raw data refer to https://github.com/mouna99/dien

Run `prepare_data.sh` to download and process data:
```
sh prepare_data.sh
```
Put data into this folder.


